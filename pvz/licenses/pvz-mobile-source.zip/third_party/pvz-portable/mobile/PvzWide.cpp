// SPDX-License-Identifier: LGPL-3.0-or-later
// Proportional Hor+ camera. Simulation and saves stay in original coordinates.
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#include <SDL.h>
#include <algorithm>
#include <array>
#include <cmath>
#include "PvzWide.h"
#include "LawnApp.h"
#include "Lawn/Board.h"
#include "Lawn/Widget/GameButton.h"
#include "SexyAppFramework/SexyAppBase.h"
#include "SexyAppFramework/graphics/GLInterface.h"
#include "SexyAppFramework/graphics/GLImage.h"
#include "SexyAppFramework/misc/MTRand.h"
#include "SexyAppFramework/widget/WidgetManager.h"

namespace {
bool pointerDown = false;
bool wideInputOwned = false;
bool fillViewport = true;
bool appliedFill = true;
bool resizePending = false;
bool insideNotification = false;
bool repainting = false;
int requestedWidth = 800;
int requestedHeight = 600;
float cameraLeft=0.0f;
float cameraWidth=800.0f;
bool cameraWide=false;
struct PointerEvent { int type,x,y; };
std::array<PointerEvent,64> pointerEvents{};
std::size_t pointerEventCount=0;

// Explicit modal dialogs can suspend the normal loop. No external callback may
// initiate another Asyncify operation while that saved stack is pending.
EM_JS(int, NativeCallbacksAvailable, (), {
    return !Asyncify.currData && Asyncify.state===0;
});

EM_JS(int, NotifyWideViewport, (int width,int height,int x,int y,int vw,int vh,int wide,float left,float logicalWidth), {
    Module['pauseMainLoop']=Module['_pvz_pause_main_loop'];
    Module['resumeMainLoop']=Module['_pvz_resume_main_loop'];
    var host=window.PvzWide;
    if (!host || typeof host.present!=='function') return 0;
    var old=Module['pvzViewportNotification'];
    if (!old || old.host!==host || old.width!==width || old.height!==height || old.x!==x || old.y!==y || old.vw!==vw || old.vh!==vh || old.wide!==wide || old.left!==left || old.logicalWidth!==logicalWidth) {
        Module['pvzViewportNotification']={host:host,width:width,height:height,x:x,y:y,vw:vw,vh:vh,wide:wide,left:left,logicalWidth:logicalWidth};
        host.present(Module.canvas, {
            version:3,width:width,height:height,cameraLeft:left,logicalWidth:logicalWidth,logicalHeight:600,wide:!!wide,
            viewport:{x:x,y:height-y-vh,width:vw,height:vh}
        });
    }
    return 1;
});

Sexy::SexyAppBase* GetApp() {
    auto* app=Sexy::gSexyAppBase;
    return app && !app->mShutdown ? app : nullptr;
}

void CancelPointer(Sexy::SexyAppBase* app) {
    if (!app || !app->mWidgetManager) return;
    auto* manager=app->mWidgetManager.get();
    bool wasDown=pointerDown;
    pointerDown=false;
    manager->MouseMove(-1000,-1000);
    if (wasDown) manager->MouseUp(-1000,-1000,1);
}

void DispatchPointer(Sexy::SexyAppBase* app,const PointerEvent& event) {
    if (!app || !app->mWidgetManager) return;
    auto* manager=app->mWidgetManager.get();
    app->mLastUserInputTick=app->mLastTimerTime;
    if (event.type==3) { CancelPointer(app); return; }
    PvzWideLayoutBoard();
    int x=event.x,y=event.y;
    // Decorative camera margins must not become an extra planting region.
    // In particular, the original PixelToGridX clamps any far-right X to col8.
    if (cameraWide && !manager->GetWidgetAt(x,y,nullptr,nullptr)) x=y=-10000;
    app->mMouseIn=true;
    manager->MouseMove(x,y);
    if (event.type==1 && !pointerDown) {
        pointerDown=true;
        manager->MouseDown(x,y,1);
    } else if (event.type==2 && pointerDown) {
        pointerDown=false;
        manager->MouseUp(x,y,1);
    }
}

void QueuePointer(PointerEvent event) {
    if (event.type==0 && pointerEventCount && pointerEvents[pointerEventCount-1].type==0) {
        pointerEvents[pointerEventCount-1]=event;
        return;
    }
    if (pointerEventCount==pointerEvents.size()) {
        // Keep button transitions ordered; discard a superseded motion first.
        std::size_t motion=0;
        while (motion<pointerEventCount && pointerEvents[motion].type!=0) ++motion;
        if (motion<pointerEventCount) {
            for (std::size_t i=motion+1;i<pointerEventCount;++i) pointerEvents[i-1]=pointerEvents[i];
            --pointerEventCount;
        } else {
            // An exceptional flood must not leave a held button behind.
            pointerEventCount=1;
            pointerEvents[0]={3,-1000,-1000};
        }
    }
    pointerEvents[pointerEventCount++]=event;
}

bool ApplyPendingResize(Sexy::SexyAppBase* app) {
    if (!resizePending || !app || !app->mWindow || !app->mGLInterface || !app->mWidgetManager || !app->mWidgetManager->mImage) return false;
    int width=0,height=0;
    auto* window=static_cast<SDL_Window*>(app->mWindow);
    SDL_GetWindowSize(window,&width,&height);
    resizePending=false;
    if (width==requestedWidth && height==requestedHeight && appliedFill==fillViewport) return false;
    pointerEventCount=0;
    CancelPointer(app);
    if (width!=requestedWidth || height!=requestedHeight) SDL_SetWindowSize(window,requestedWidth,requestedHeight);
    app->mGLInterface->UpdateViewport();
    // Switching to contain without changing dimensions must clear the old bars.
    glClearColor(0.0f,0.0f,0.0f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    app->mWidgetManager->Resize(app->mScreenBounds,app->mGLInterface->mPresentationRect);
    app->mWidgetManager->MarkAllDirty();
    appliedFill=fillViewport;
    return true;
}

void RepaintStatic(Sexy::SexyAppBase* app) {
    if (!app || app->mIsDrawing || repainting || insideNotification || !app->mWidgetManager || !app->mWidgetManager->mImage || !app->mGLInterface) return;
    // Do not run UpdateAppStep/DrawDirtyStuff: pause must not advance simulation
    // or accumulate elapsed time just because the browser changed orientation.
    repainting=true;
    Sexy::MTAutoDisallowRand randomGuard;
    app->mIsDrawing=true;
    app->mWidgetManager->DrawScreen();
    app->mIsDrawing=false;
    app->mGLInterface->Redraw(nullptr);
    repainting=false;
}
}

float PvzWideCameraLeft() { return cameraLeft; }
float PvzWideCameraWidth() { return cameraWidth; }
bool PvzWideEnabled() { return cameraWide; }
bool PvzWideFillViewport() { return cameraWide; }
bool PvzWideRootVisible(const Sexy::Widget* widget) {
    if (!cameraWide || !widget || widget->mParent!=widget->mWidgetManager) return true;
    // The selector parks whole screens at X=800. A wider camera must not make
    // those inactive roots visible or clickable; shifted children stay valid.
    return widget->mX<800 && widget->mX+widget->mWidth>0 && widget->mY<600 && widget->mY+widget->mHeight>0;
}

void PvzWideLayoutBoard() {
    auto* app=GetApp();
    if (!app || app!=gLawnApp || !gLawnApp->mBoard) return;
    auto* board=gLawnApp->mBoard;
    if (board->mMenuButton) {
        const int gap=board->mMenuButton->mWidth==117 ? 2 : 9;
        board->mMenuButton->mX=static_cast<int>(std::floor(cameraLeft+cameraWidth))-board->mMenuButton->mWidth-gap;
    }
}

void PvzWideUpdateCamera(int width,int height) {
    auto* app=GetApp();
    if (!app || !app->mGLInterface) return;
    bool nextWide=fillViewport && height>0 && width*3>height*4;
    float nextWidth=nextWide ? 600.0f*width/height : 800.0f;
    float nextLeft=std::floor((800.0f-nextWidth)*0.5f);
    // Ordinary board art is an existing 1400x600 panorama at world X=-220.
    // Keep the full camera inside that art when its width permits it.
    if (nextWide && app==gLawnApp && gLawnApp->mBoard && nextWidth<=1400.0f) {
        switch (gLawnApp->mBoard->mBackground) {
        case BackgroundType::BACKGROUND_1_DAY:
        case BackgroundType::BACKGROUND_2_NIGHT:
        case BackgroundType::BACKGROUND_3_POOL:
        case BackgroundType::BACKGROUND_4_FOG:
        case BackgroundType::BACKGROUND_5_ROOF:
        case BackgroundType::BACKGROUND_6_BOSS:
            nextLeft=std::floor(std::clamp(nextLeft,-220.0f,1180.0f-nextWidth));
            break;
        default: break;
        }
    }
    bool changed=nextWide!=cameraWide || nextWidth!=cameraWidth || nextLeft!=cameraLeft;
    cameraWide=nextWide; cameraWidth=nextWidth; cameraLeft=nextLeft;
    const int logicalWidth=static_cast<int>(std::ceil(cameraWidth));
    app->mGLInterface->mWidth=logicalWidth;
    app->mGLInterface->mHeight=600;
    if (auto* screen=app->mGLInterface->GetScreenImage()) {
        screen->mWidth=logicalWidth;
        screen->mHeight=600;
    }
    app->mScreenBounds=Sexy::Rect(static_cast<int>(cameraLeft),0,logicalWidth,600);
    if (app->mWidgetManager) {
        app->mWidgetManager->Resize(app->mScreenBounds,app->mGLInterface->mPresentationRect);
        if (changed) app->mWidgetManager->MarkAllDirty();
    }
    PvzWideLayoutBoard();
}

// Called by the ordinary input pump, including its nested modal-dialog pump.
// Pop before dispatch: MouseUp may open a dialog and suspend through Asyncify.
bool PvzWideProcessPointer() {
    if (!pointerEventCount) return false;
    auto event=pointerEvents[0];
    for (std::size_t i=1;i<pointerEventCount;++i) pointerEvents[i-1]=pointerEvents[i];
    --pointerEventCount;
    DispatchPointer(GetApp(),event);
    return true;
}

// Invoked before WidgetManager starts submitting any draw commands.
void PvzWideBeforeDraw() {
    auto* app=GetApp();
    if (!insideNotification) ApplyPendingResize(app);
    // A scene change can alter camera framing without changing canvas size.
    if (app && app->mGLInterface) app->mGLInterface->UpdateViewport();
}

void PvzWidePresent() {
    auto* app=GetApp();
    if (!app || !app->mWindow || !app->mGLInterface || insideNotification) return;
    int width=0,height=0;
    SDL_GL_GetDrawableSize(static_cast<SDL_Window*>(app->mWindow),&width,&height);
    auto r=app->mGLInterface->mPresentationRect;
    insideNotification=true;
    bool ownsInput=NotifyWideViewport(width,height,r.mX,r.mY,r.mWidth,r.mHeight,cameraWide,cameraLeft,cameraWidth)!=0;
    insideNotification=false;
    if (ownsInput!=wideInputOwned) {
        // SDL also registers mouseup on document. Only the direct pointer path
        // owns mouse events while the browser host is attached; keyboard remains.
        SDL_EventState(SDL_MOUSEMOTION,ownsInput ? SDL_IGNORE : SDL_ENABLE);
        SDL_EventState(SDL_MOUSEBUTTONDOWN,ownsInput ? SDL_IGNORE : SDL_ENABLE);
        SDL_EventState(SDL_MOUSEBUTTONUP,ownsInput ? SDL_IGNORE : SDL_ENABLE);
        wideInputOwned=ownsInput;
    }
}

extern "C" EMSCRIPTEN_KEEPALIVE int pvz_resize(int width,int height,int fill) {
    requestedWidth=std::clamp(width,1,4096);
    requestedHeight=std::clamp(height,1,4096);
    fillViewport=fill!=0;
    resizePending=true;
    auto* app=GetApp();
    if (!app || !app->mWindow || !app->mGLInterface || !app->mWidgetManager || !app->mWidgetManager->mImage || app->mIsDrawing || insideNotification || repainting || !NativeCallbacksAvailable()) return 0;
    if (ApplyPendingResize(app)) RepaintStatic(app);
    PvzWidePresent();
    return 1;
}

extern "C" EMSCRIPTEN_KEEPALIVE void pvz_pointer(int type,int x,int y) {
    auto* app=GetApp();
    if (!app || !app->mWidgetManager || type<0 || type>3) return;
    int minX=static_cast<int>(std::floor(cameraLeft));
    int maxX=static_cast<int>(std::ceil(cameraLeft+cameraWidth))-1;
    QueuePointer({type,std::clamp(x,minX,maxX),std::clamp(y,0,599)});
}

extern "C" EMSCRIPTEN_KEEPALIVE void pvz_pause_main_loop() { emscripten_pause_main_loop(); }
extern "C" EMSCRIPTEN_KEEPALIVE void pvz_resume_main_loop() { emscripten_resume_main_loop(); }
#endif
