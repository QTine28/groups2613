// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
namespace Sexy { class Widget; }

// World coordinates remain based on the original 800x600 game. A wider camera
// reveals scenery while the projection keeps an identical X/Y pixel scale.
float PvzWideCameraLeft();
float PvzWideCameraWidth();
bool PvzWideEnabled();
void PvzWideUpdateCamera(int width,int height);
void PvzWideLayoutBoard();
bool PvzWideRootVisible(const Sexy::Widget* widget);
