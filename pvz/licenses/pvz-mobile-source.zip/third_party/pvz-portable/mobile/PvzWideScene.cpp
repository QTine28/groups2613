// SPDX-License-Identifier: LGPL-3.0-or-later
#ifdef __EMSCRIPTEN__
#include "PvzWideScene.h"
#include "PvzWide.h"
#include "Resources.h"
#include "LawnApp.h"
#include "Lawn/Widget/GameSelector.h"
#include "PvzpLib/Reanimator.h"
#include "SexyAppFramework/graphics/Graphics.h"
#include "SexyAppFramework/graphics/Image.h"
#include <algorithm>
#include <cmath>
#include <cstring>

using namespace Sexy;

// Extend scenery only. Foreground widgets and actors keep their original size.
// Reflection tiles use source pixels at 1:1, never independent X/Y scaling.
void PvzWideDrawBackdrop(Graphics* g, Image* image, int x, int y) {
    if (!image) return;
    if (PvzWideEnabled() && image == IMAGE_CHALLENGE_BACKGROUND) {
        // Expand the empty panel, preserving the carved end caps at 1:1.
        // Repeating the image edges would produce extra framed panels.
        const int left=static_cast<int>(std::floor(PvzWideCameraLeft()));
        const int width=static_cast<int>(std::ceil(PvzWideCameraWidth()));
        const int cap=176, w=image->GetWidth(), h=image->GetHeight();
        g->DrawImage(image,left,y,Rect(0,0,cap,h));
        g->DrawImage(image,Rect(left+cap,y,width-2*cap,h),Rect(cap,0,w-2*cap,h));
        g->DrawImage(image,left+width-cap,y,Rect(w-cap,0,cap,h));
        return;
    }
    if (PvzWideEnabled()) {
        const int left=static_cast<int>(std::floor(g->mClipRect.mX-g->mTransX));
        const int right=static_cast<int>(std::ceil(g->mClipRect.mX+g->mClipRect.mWidth-g->mTransX));
        const int w=image->GetWidth(), h=image->GetHeight();
        const int strip=std::min(128,w);
        if (strip>0) {
            bool mirror=true;
            for (int edge=x;edge>left;edge-=strip,mirror=!mirror)
                g->DrawImageMirror(image,edge-strip,y,Rect(0,0,strip,h),mirror);
            mirror=true;
            for (int edge=x+w;edge<right;edge+=strip,mirror=!mirror)
                g->DrawImageMirror(image,edge,y,Rect(w-strip,0,strip,h),mirror);
        }
    }
    g->DrawImage(image,x,y);
}

// Title art is a background; its independent logo/loading controls stay in place.
void PvzWideDrawCover(Graphics* g, Image* image) {
    if (!image) return;
    if (!PvzWideEnabled()) { g->DrawImage(image,0,0); return; }
    const float scale=std::max(PvzWideCameraWidth()/image->GetWidth(),600.0f/image->GetHeight());
    const int w=static_cast<int>(std::ceil(image->GetWidth()*scale));
    const int h=static_cast<int>(std::ceil(image->GetHeight()*scale));
    const int x=static_cast<int>(std::floor(PvzWideCameraLeft()+(PvzWideCameraWidth()-w)*0.5f));
    g->DrawImage(image,Rect(x,(600-h)/2,w,h),Rect(0,0,image->GetWidth(),image->GetHeight()));
}

float PvzWideSelectorOffset(GameSelector* selector,const char* track) {
    if (!PvzWideEnabled() || !selector || !track) return 0;
    const float phase=std::clamp(1.0f-std::abs(selector->mX)/800.0f-std::abs(selector->mY)/600.0f,0.0f,1.0f);
    if (std::strncmp(track,"woodsign",8)==0 || std::strcmp(track,"SelectorScreen_BG_Left")==0)
        return PvzWideCameraLeft()*phase;
    if (std::strcmp(track,"almanac_key_shadow")==0 || (std::strncmp(track,"SelectorScreen_",15)==0 &&
        std::strcmp(track,"SelectorScreen_BG")!=0 && std::strcmp(track,"SelectorScreen_BG_Center")!=0))
        return (PvzWideCameraLeft()+PvzWideCameraWidth()-800.0f)*phase;
    return 0;
}

void PvzWideSelectorTrack(Reanimation* reanim,int index,ReanimatorTransform* transform) {
    if (!PvzWideEnabled() || !gLawnApp || !gLawnApp->mGameSelector) return;
    auto* selector=gLawnApp->mGameSelector.get();
    if (gLawnApp->ReanimationTryToGet(selector->mSelectorReanimID)!=reanim) return;
    const char* name=reanim->mDefinition->mTracks.tracks[index].mName;
    transform->mTransX+=PvzWideSelectorOffset(selector,name);
    const float phase=std::clamp(1.0f-std::abs(selector->mX)/800.0f-std::abs(selector->mY)/600.0f,0.0f,1.0f);
    if (std::strcmp(name,"SelectorScreen_BG")==0 || std::strcmp(name,"SelectorScreen_BG_Center")==0) {
        // Uniform cover of the sky/landscape layers: the house remains proportional.
        const float scale=1.0f+(PvzWideCameraWidth()/800.0f-1.0f)*phase;
        const float center=400.0f+(PvzWideCameraLeft()+PvzWideCameraWidth()*0.5f-400.0f)*phase;
        transform->mTransX=center+(transform->mTransX-400.0f)*scale;
        transform->mTransY=600.0f+(transform->mTransY-600.0f)*scale;
        transform->mScaleX*=scale;
        transform->mScaleY*=scale;
    }
}
#endif
