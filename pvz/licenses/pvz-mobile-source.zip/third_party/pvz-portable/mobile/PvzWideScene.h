// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#ifdef __EMSCRIPTEN__
#include "PvzWide.h"
namespace Sexy { class Graphics; class Image; }
class Reanimation;
class ReanimatorTransform;
class GameSelector;
void PvzWideDrawBackdrop(Sexy::Graphics*, Sexy::Image*, int, int);
void PvzWideDrawCover(Sexy::Graphics*, Sexy::Image*);
void PvzWideSelectorTrack(Reanimation*, int, ReanimatorTransform*);
float PvzWideSelectorOffset(GameSelector*, const char*);
#endif
