// SPDX-License-Identifier: LGPL-3.0-or-later
#ifdef __EMSCRIPTEN__
#include "PvzWideTree.h"
#include "PvzWide.h"
#include "PvzpLib/Reanimator.h"
#include "SexyAppFramework/graphics/Graphics.h"
#include <algorithm>
#include <cmath>

using namespace Sexy;

void PvzWideDrawTreeGroup(Graphics* graphics,Reanimation* tree,int group) {
    if (!tree || !graphics) return;
    if (!PvzWideEnabled()) { tree->DrawRenderGroup(graphics,group); return; }
    const int left=graphics->mClipRect.mX-static_cast<int>(graphics->mTransX);
    const int right=left+graphics->mClipRect.mWidth;
    const int top=graphics->mClipRect.mY-static_cast<int>(graphics->mTransY);
    if (group==0) {
        // Only the background group covers the wider view. The tree itself,
        // roots, clouds and interaction coordinates keep their original size.
        const float scale=std::max(1.0f,PvzWideCameraWidth()/800.0f);
        const float center=left+PvzWideCameraWidth()*0.5f;
        const auto original=tree->mOverlayMatrix;
        auto cover=original;
        cover.m00*=scale; cover.m01*=scale;
        cover.m02=original.m02*scale+center-400.0f*scale;
        cover.m10*=scale; cover.m11*=scale;
        cover.m12=original.m12*scale+top+600.0f-600.0f*scale;
        tree->mOverlayMatrix=cover;
        tree->DrawRenderGroup(graphics,group);
        tree->mOverlayMatrix=original;
        return;
    }
    tree->DrawRenderGroup(graphics,group);
    if (group!=3) return;
    // Ground stays at 1:1, so it cannot grow over the trunk. Side-only clips
    // admit copies outside [0,800] while leaving the original center intact.
    if (left<0) {
        Graphics margin(*graphics);
        margin.ClipRect(left,top,-left,600);
        for (int offset=-800;offset+800>left;offset-=800) {
            Graphics tile(margin);
            tile.Translate(offset,0);
            tree->DrawRenderGroup(&tile,group);
        }
    }
    if (right>800) {
        Graphics margin(*graphics);
        margin.ClipRect(800,top,right-800,600);
        for (int offset=800;offset<right;offset+=800) {
            Graphics tile(margin);
            tile.Translate(offset,0);
            tree->DrawRenderGroup(&tile,group);
        }
    }
}
#endif
