// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#ifdef __EMSCRIPTEN__
namespace Sexy { class Graphics; }
class Reanimation;
void PvzWideDrawTreeGroup(Sexy::Graphics* graphics,Reanimation* tree,int group);
#endif
