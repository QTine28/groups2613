# Proportional mobile camera and scene layout

This directory contains the modifications to PvZ-Portable 0.2.6
(`396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca`). The engine still simulates and
saves in its original 800x600 coordinates. A native Hor+ camera reveals more
scenery horizontally while sprites, text and controls retain their proportions.
Rendering goes directly to WebGL, with no intermediate 2D canvas or cropped lawn.

## Rendering and input contract

`Module._pvz_resize(width, height, wide)` changes the SDL window and WebGL drawing
buffer. Dimensions are positive integer physical pixels, bounded to 1..4096;
the host applies a uniform device-pixel-ratio cap before requesting the size.
`SDL_WINDOW_ALLOW_HIGHDPI` stays disabled so SDL does not apply DPR again.

`wide=1` on a wider-than-4:3 surface uses a 600-unit camera height and camera
width `600 * drawingBufferWidth / drawingBufferHeight`. The same physical-pixel
scale applies to both axes. `wide=0`, including portrait surfaces, retains the
original 4:3 camera with letterboxing. The top seed bank and shovel stay above
the original lawn; the board menu anchors to the camera's right edge.

Ordinary day/night/pool/fog/roof/boss backgrounds already contain 1400x600
panoramas at world X=-220. The camera uses that existing scenery, clamping its
left edge within the panorama when possible. Other scenes remain centered on
their original layout. Background-only reflection tiles extend missing scenery;
title and selector scenery use uniform cover scaling. Selector signs and button
groups move with their hit targets. Foreground sprites and text are not stretched.
The challenge-selection background uses original-size edge caps and a stretched
empty center, so its panel border is extended without duplicating trophy caps.
Tree of Wisdom scales only its background render group uniformly; its original
ground is retained and repeated into side-only clips, leaving the trunk and roots
unchanged. Direct matrix-based labels and projectile effects explicitly include
the camera translation, matching the regular Graphics rendering path.
The nine gameplay columns, object positions, spawn/despawn rules and timing
remain unchanged; the extra visible margins are scenery, not planting spaces.

`GLInterface::UpdateViewport` updates the projection and expands the existing
screen image in place. `mScreenBounds` carries the camera rectangle; the existing
WidgetManager translation applies it to complete objects and overlays. The app's
800x600 gameplay dimensions stay unchanged. A hook before
`WidgetManager::DrawScreen` applies queued startup/reentrant resize requests
before any vertices are submitted. A resize clears the whole drawing buffer,
including newly exposed letterbox bars. Static repaint uses only
`WidgetManager::DrawScreen`/`GLInterface::Redraw`, so resizing a paused game does
not resume the loop, run simulation updates or change the timing accumulator.
SDL's automatic Asyncify sleep during `SDL_GL_SwapWindow` is disabled with
`SDL_HINT_EMSCRIPTEN_ASYNCIFY=0`: the engine already uses Emscripten's rAF main
loop. A second swap-triggered sleep from an external resize would overwrite the
normal loop's suspended Asyncify stack. Explicit modal-dialog sleeps remain;
external resize callbacks defer while such a stack is pending and apply at the
next native draw boundary.
The startup hint is patched in `platform/emscripten/Window.cpp`, which CMake
selects for WebAssembly; input dispatch uses `platform/default/Input.cpp`.

`GLInterface::Flush` sends geometry notifications through
`window.PvzWide.present(Module.canvas, state)` only when dimensions, viewport,
camera, mode or attached host change. Version 3 state includes `width`, `height`,
`cameraLeft`, `logicalWidth` (the camera width), `logicalHeight:600`, `wide`,
and `viewport:{x,y,width,height}`.
The viewport uses top-left coordinates for browser input, with OpenGL's Y origin
converted explicitly. The callback does not copy any pixels. Host resize calls
should run from requestAnimationFrame outside this callback.

`Module._pvz_pointer(type, x, y)` receives signed world coordinates. Types
are 0 (move), 1 (left down), 2 (left up), and 3 (cancel). Cancellation releases
off-board so a resize or pointer cancellation cannot activate the last button.
The export only enqueues input. The ordinary native input pump dispatches it,
including inside a modal dialog, so browser callbacks cannot start competing
Asyncify operations. The 64-event queue coalesces adjacent movement, preserves
button-transition order, and cancels safely if an exceptional flood fills it.
The visible canvas must prevent duplicate compatibility mouse events and
release/cancel on focus loss, visibility changes, and layout changes.
SDL compatibility mouse events are disabled while the host owns pointer input;
keyboard input remains active. Host input must reject letterbox points and map
viewport X to `cameraLeft + u * logicalWidth` and Y to `v * 600`. The board accepts
its original playable rectangle plus the relocated menu. Decorative margin hits
cannot fall through to the original clamped last-column planting logic. Inactive
root screens parked outside the original frame remain hidden and noninteractive;
repositioned children of an active screen remain available.

## Reproducible Windows build

All SDK and build files are checkout-local; no system environment changes are
needed. Install Git, Python 3.11+, CMake and Ninja, then from the project root:

```powershell
git clone --depth 1 https://github.com/emscripten-core/emsdk.git local/emsdk
python local/emsdk/emsdk.py install 4.0.23
python local/emsdk/emsdk.py activate 4.0.23
git clone --depth 1 --branch libopenmpt-0.8.4 https://github.com/OpenMPT/openmpt.git local/libopenmpt
python tools/build_mobile_engine.py --cmake C:/Tools/cmake/bin/cmake.exe --ninja C:/Tools/ninja.exe
```

If the upstream game checkout is absent, clone it into `vendor/PvZ-Portable` and
check out the pinned commit first. The build script applies the bridge with
strict source anchors, builds the static music library with the source groups
from upstream's Makefile, then compiles the actual native game to WebAssembly.
`libopenmpt` is pinned to commit `327204eaa2c27bd1acbb571babe68f279c85238b`.

Outputs are `local/build-mobile/pvz-portable.js` and `pvz-portable.wasm`.
They are not automatically installed in `dist/engine`; validate before replacing
the deployed runtime. The generated Emscripten shell is not used: the project
retains its Telegram shell, resource cache, and save persistence layer.
Use `--diagnostics` to retain native function names and a symbol map and enable
Emscripten runtime assertions and stack checks when investigating browser faults.

`FS` and `callMain` are explicitly exported runtime helpers. Native exports
`_pvz_pause_main_loop` and `_pvz_resume_main_loop` provide the wrapper's existing
`Module.pauseMainLoop`/`Module.resumeMainLoop` names after the first frame.
The Emscripten compiler is 4.0.23, whose SDK release hash is
`aaa43392544d695232b70eda706d751f18980c2a`.

The bridge is LGPL-3.0-or-later. Original engine licenses are retained alongside
the complete corresponding source archive and this directory.
