"""Apply the version-pinned browser presentation bridge to PvZ-Portable source."""
from pathlib import Path
import shutil
from apply_wide_effects import apply as apply_wide_effects
from apply_wide_scene import main as apply_wide_scene
from apply_wide_tree import main as apply_wide_tree

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "vendor" / "PvZ-Portable"
BRIDGE = ROOT / "third_party" / "pvz-portable" / "mobile" / "PvzWide.cpp"


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    if new in text:
        return
    if text.count(old) != 1:
        raise RuntimeError(f"Unexpected upstream source at {path}: expected one patch anchor")
    path.write_text(text.replace(old, new), encoding="utf-8", newline="\n")


def replace_count(path: Path, old: str, new: str, count: int) -> None:
    text=path.read_text(encoding='utf-8')
    if text.count(new)==count: return
    if text.count(old)!=count: raise RuntimeError(f'Unexpected repeated anchor at {path}')
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')


def main() -> None:
    shutil.copyfile(BRIDGE, SOURCE / "src" / "PvzWide.cpp")
    shutil.copyfile(BRIDGE.with_suffix('.h'), SOURCE / "src" / "PvzWide.h")
    apply_wide_effects(SOURCE)
    apply_wide_scene()
    apply_wide_tree()
    replace_once(SOURCE / "src" / "SexyAppFramework" / "graphics" / "GLInterface.cpp",
        "void GLInterface::Flush()\n{\n\tGfxFlush();",
        "#ifdef __EMSCRIPTEN__\nextern void PvzWidePresent();\n#endif\n\nvoid GLInterface::Flush()\n{\n\tGfxFlush();\n#ifdef __EMSCRIPTEN__\n\tPvzWidePresent();\n#endif")
    replace_once(SOURCE / "src" / "SexyAppFramework" / "graphics" / "GLInterface.cpp",
        "void GLInterface::UpdateViewport()",
        "#ifdef __EMSCRIPTEN__\nextern bool PvzWideFillViewport();\n#endif\n\nvoid GLInterface::UpdateViewport()")
    replace_once(SOURCE / "src" / "SexyAppFramework" / "graphics" / "GLInterface.cpp",
        "\t// Letterbox to 4:3\n\tif (width * 3 > height * 4)",
        "\tbool contain = true;\n#ifdef __EMSCRIPTEN__\n\tcontain = !PvzWideFillViewport();\n#endif\n\t// The browser host explicitly selects full-window or original-aspect mode.\n\tif (contain && width * 3 > height * 4)")
    replace_once(SOURCE / "src" / "SexyAppFramework" / "graphics" / "GLInterface.cpp",
        "\telse if (width * 3 < height * 4)",
        "\telse if (contain && width * 3 < height * 4)")
    replace_once(SOURCE / "src" / "SexyAppFramework" / "widget" / "WidgetManager.cpp",
        "bool WidgetManager::DrawScreen()\n{",
        "#ifdef __EMSCRIPTEN__\nextern void PvzWideBeforeDraw();\nextern bool PvzWideRootVisible(const Sexy::Widget* widget);\n#endif\n\nbool WidgetManager::DrawScreen()\n{\n#ifdef __EMSCRIPTEN__\n\tPvzWideBeforeDraw();\n#endif")
    replace_once(SOURCE / "src" / "SexyAppFramework" / "platform" / "emscripten" / "Window.cpp",
        "void SexyAppBase::MakeWindow()\n{",
        "void SexyAppBase::MakeWindow()\n{\n#ifdef __EMSCRIPTEN__\n\t// The engine already yields through emscripten_set_main_loop. A second\n\t// Asyncify sleep in SDL_GL_SwapWindow corrupts a suspended resize/dialog.\n\tSDL_SetHint(SDL_HINT_EMSCRIPTEN_ASYNCIFY, \"0\");\n#endif")
    replace_once(SOURCE / "src" / "SexyAppFramework" / "platform" / "default" / "Input.cpp",
        "bool SexyAppBase::ProcessDeferredMessages(bool singleMessage)\n{",
        "#ifdef __EMSCRIPTEN__\nextern bool PvzWideProcessPointer();\n#endif\n\nbool SexyAppBase::ProcessDeferredMessages(bool singleMessage)\n{\n#ifdef __EMSCRIPTEN__\n\tif (PvzWideProcessPointer()) return true;\n#endif")
    gl = SOURCE / 'src/SexyAppFramework/graphics/GLInterface.cpp'
    replace_once(gl, '#include "SexyAppBase.h"', '#include "SexyAppBase.h"\n#ifdef __EMSCRIPTEN__\n#include "PvzWide.h"\n#endif')
    replace_once(gl, '\tvw = width; vh = height;', '#ifdef __EMSCRIPTEN__\n\tPvzWideUpdateCamera(width,height);\n#endif\n\tvw = width; vh = height;')
    replace_once(gl, '\tmPresentationRect = Rect(vx, vy, vw, vh);', '''\tmPresentationRect = Rect(vx, vy, vw, vh);
#ifdef __EMSCRIPTEN__
\tif (gProgram)
\t{
\t\tfloat ortho[16];
\t\tMakeOrthoMatrix(0, PvzWideCameraWidth(), 600, 0, -10, 10, ortho);
\t\tglUseProgram(gProgram);
\t\tglUniformMatrix4fv(gUfViewProjMtx, 1, GL_FALSE, ortho);
\t}
#endif''')
    manager = SOURCE / 'src/SexyAppFramework/widget/WidgetManager.cpp'
    replace_once(manager, 'extern void PvzWideBeforeDraw();', 'extern void PvzWideBeforeDraw();\nextern bool PvzWideRootVisible(const Sexy::Widget* widget);')
    replace_once(manager, '\t\t\tWidget* aWidget = *anItr;\n\n\t\t\tif (aWidget == mWidgetManager->mBaseModalWidget)', '''\t\t\tWidget* aWidget = *anItr;
#ifdef __EMSCRIPTEN__
\t\t\tif (!PvzWideRootVisible(aWidget)) { ++anItr; continue; }
#endif
\n\t\t\tif (aWidget == mWidgetManager->mBaseModalWidget)''')
    container = SOURCE / 'src/SexyAppFramework/widget/WidgetContainer.cpp'
    replace_once(container, 'Widget* WidgetContainer::GetWidgetAtHelper(int x, int y, int theFlags, bool* found, int* theWidgetX, int* theWidgetY)', '''#ifdef __EMSCRIPTEN__
extern bool PvzWideRootVisible(const Sexy::Widget* widget);
#endif
\nWidget* WidgetContainer::GetWidgetAtHelper(int x, int y, int theFlags, bool* found, int* theWidgetX, int* theWidgetY)''')
    replace_once(container, '\t\tint aCurFlags = theFlags;', '''#ifdef __EMSCRIPTEN__
\t\tif (!PvzWideRootVisible(aWidget)) { ++anItr; continue; }
#endif
\t\tint aCurFlags = theFlags;''')
    board_header = SOURCE / 'src/Lawn/Board.h'
    replace_once(board_header, 'class Board : public Widget, public ButtonListener\n{\npublic:', '''class Board : public Widget, public ButtonListener
{
public:
#ifdef __EMSCRIPTEN__
\tRect GetInsetRect() override;
\tbool IsPointVisible(int x,int y) override;
#endif''')
    board = SOURCE / 'src/Lawn/Board.cpp'
    replace_once(board, '#include "../PvzWide.h"', '#include "../PvzWide.h"\n#include "../PvzWideScene.h"')
    for call,count in (
        ('g->DrawImage(Sexy::IMAGE_BACKGROUND1UNSODDED, -BOARD_OFFSET, 0);',3),
        ('g->DrawImage(aBgImage, 0, 0);',1),
        ('g->DrawImage(aBgImage, -BOARD_OFFSET, 0);',1)):
        replacement=call.replace('g->DrawImage(', 'PvzWideDrawBackdrop(g, ')
        replace_count(board,call, '#ifdef __EMSCRIPTEN__\n\t\t'+replacement+'\n#else\n\t\t'+call+'\n#endif',count)
    replace_once(board, 'void Board::MouseMove(int x, int y)', '''#ifdef __EMSCRIPTEN__
Rect Board::GetInsetRect()
{
\tif (!PvzWideEnabled()) return Widget::GetInsetRect();
\treturn Rect(static_cast<int>(PvzWideCameraLeft()),mY,static_cast<int>(PvzWideCameraWidth())+1,mHeight);
}
bool Board::IsPointVisible(int x,int y)
{
\tif (!PvzWideEnabled() || (x>=0 && x<800 && y>=0 && y<600)) return true;
\treturn mMenuButton && !mMenuButton->mBtnNoDraw &&
\t\tRect(mMenuButton->mX,mMenuButton->mY,mMenuButton->mWidth,mMenuButton->mHeight).Contains(x+mX,y+mY);
}
#endif
\nvoid Board::MouseMove(int x, int y)''')
    replace_once(board, '\tmMenuButton->Draw(g);', '''#ifdef __EMSCRIPTEN__
\tif (PvzWideEnabled())
\t{
\t\tGraphics aWideMenuG(*g);
\t\taWideMenuG.Translate(-mX,-mY);
\t\tmMenuButton->Draw(&aWideMenuG);
\t}
\telse
#endif
\t\tmMenuButton->Draw(g);''')
    print("Applied the mobile presentation bridge.")


if __name__ == "__main__":
    main()
