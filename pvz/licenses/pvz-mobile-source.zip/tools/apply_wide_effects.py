"""Adapt screen effects and explicit matrices to the native Hor+ camera."""
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "vendor" / "PvZ-Portable"


def replace_exact(path: Path, old: str, new: str, count: int = 1) -> None:
    text = path.read_text(encoding="utf-8")
    if text.count(new) == count:
        return
    if text.count(old) != count or new in text:
        raise RuntimeError(f"Unexpected upstream source at {path}: expected {count} effect anchors")
    path.write_text(text.replace(old, new), encoding="utf-8", newline="\n")


def include_camera_api(path: Path, anchor: str) -> None:
    text = path.read_text(encoding="utf-8")
    if '#include "../PvzWide.h"' in text:
        return
    replace_exact(path, anchor, anchor + '\n#ifdef __EMSCRIPTEN__\n#include "../PvzWide.h"\n#endif')


def camera_fill(old: str, board: str) -> str:
    indent = old[:len(old) - len(old.lstrip("\t"))]
    return (
        "#ifdef __EMSCRIPTEN__\n"
        + indent + f"g->FillRect(PvzWideCameraLeft() - {board}mX, -{board}mY, static_cast<int>(PvzWideCameraWidth()) + 1, BOARD_HEIGHT);\n"
        + "#else\n" + old + "\n#endif"
    )


def apply(source: Path = SOURCE) -> None:
    board = source / "src" / "Lawn" / "Board.cpp"
    intro = source / "src" / "Lawn" / "CutScene.cpp"
    reanimation = source / "src" / "PvzpLib" / "Reanimator.cpp"
    messages = source / "src" / "Lawn" / "MessageWidget.cpp"
    packets = source / "src" / "Lawn" / "SeedPacket.cpp"
    title = source / "src" / "Lawn" / "Widget" / "TitleScreen.cpp"
    challenge = source / "src" / "Lawn" / "Challenge.cpp"
    projectile = source / "src" / "Lawn" / "Projectile.cpp"
    include_camera_api(board, '#include "BoardInclude.h"')
    include_camera_api(intro, '#include "Board.h"')

    # Migrate the first local version, which implicitly truncated fractional
    # camera widths. One extra logical pixel is clipped by the screen image.
    for path in (board, intro):
        text = path.read_text(encoding="utf-8")
        previous = "PvzWideCameraWidth(), BOARD_HEIGHT);"
        if previous in text:
            path.write_text(text.replace(previous, "static_cast<int>(PvzWideCameraWidth()) + 1, BOARD_HEIGHT);"), encoding="utf-8", newline="\n")

    # Board transforms include its cutscene camera position. These effects are
    # screen overlays, so cancel that position before filling the wider camera.
    old = "\tg->FillRect(0, 0, mWidth, mHeight);"
    replace_exact(board, old, camera_fill(old, ""))
    old = "\t\tg->FillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);"
    replace_exact(board, old, camera_fill(old, ""), 2)

    # The intro already cancels the board pan; expand only its black curtains
    # and fade, retaining the logo and its animated 800-pixel banner geometry.
    old = "\t\tg->FillRect(-mBoard->mX, -mBoard->mY, BOARD_WIDTH, BOARD_HEIGHT);"
    replace_exact(intro, old, camera_fill(old, "mBoard->"), 2)

    # Reanimation's fullscreen track and ignore-clip path use target-image
    # coordinates, so they must cover the actual drawing surface.
    replace_exact(reanimation,
        "\t\tg->FillRect(-g->mTransX, -g->mTransY, BOARD_WIDTH, BOARD_HEIGHT);",
        "\t\tg->FillRect(-g->mTransX, -g->mTransY, g->mDestImage->GetWidth(), g->mDestImage->GetHeight());")
    replace_exact(reanimation,
        "\t\taClipRect = Rect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);",
        "\t\taClipRect = Rect(0, 0, g->mDestImage->GetWidth(), g->mDestImage->GetHeight());")

    # Reanimated advice is anchored to the screen, independent of the board's
    # intro pan. Add only the camera component of the Graphics translation.
    old = "\t\tReanimation::MatrixFromTransform(aTransform, aMatrix);"
    replace_exact(messages, old, old + "\n#ifdef __EMSCRIPTEN__\n"
        "\t\tSexyMatrix3Translation(aMatrix, g->mTransX - mApp->mBoard->mX, g->mTransY - mApp->mBoard->mY);\n"
        "#endif")

    # These callers construct local matrices, but PvzpDrawStringMatrix and
    # PvzpBltMatrix consume absolute target coordinates. Their normal image
    # counterparts already include Graphics translation.
    old = "\t\t\tPvzpScaleTransformMatrix(aMatrix, aTextOffsetX * g->mScaleX + x, aTextOffsetY * g->mScaleY + y, g->mScaleX, g->mScaleY);"
    replace_exact(packets, old, old + "\n#ifdef __EMSCRIPTEN__\n"
        "\t\t\tSexyMatrix3Translation(aMatrix, g->mTransX, g->mTransY);\n#endif")
    old = "\t\tPvzpScaleRotateTransformMatrix(aTransform, aGrassX + 11.0f + aRollLen, aGrassY - 3.0f - 35.0f * aScale + 35.0f, aRotation, aScale, aScale);"
    replace_exact(title, old, old + "\n#ifdef __EMSCRIPTEN__\n"
        "\t\tSexyMatrix3Translation(aTransform, g->mTransX, g->mTransY);\n#endif")
    old = "\t\t\tPvzpScaleRotateTransformMatrix(aTransform, aPixelX, aPixelY, aRotation, 1, 1);"
    replace_exact(challenge, old, old + "\n#ifdef __EMSCRIPTEN__\n"
        "\t\t\tSexyMatrix3Translation(aTransform, g->mTransX, g->mTransY);\n#endif")

    # Projectile matrices already include their world position and the board
    # pan. Only the camera translation is missing from this absolute path.
    old = "\t\t\tPvzpScaleRotateTransformMatrix(aTransform, aOffsetX + mBoard->mX, aOffsetY + mBoard->mY, mRotation, aScale, aScale);"
    replace_exact(projectile, old, old + "\n#ifdef __EMSCRIPTEN__\n"
        "\t\t\tSexyMatrix3Translation(aTransform, g->mTransX - mX - mBoard->mX, g->mTransY - mY - mBoard->mY);\n#endif")


def main() -> None:
    apply()
    print("Applied camera-wide screen effects and scoped matrix offsets.")


if __name__ == "__main__":
    main()
