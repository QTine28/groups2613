"""Apply native proportional scenery and main-menu anchors to the pinned source."""
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'vendor/PvZ-Portable/src'


def patch(path, old, new):
    text=path.read_text(encoding='utf-8')
    if new in text:return
    if text.count(old)!=1:raise RuntimeError(f'Unexpected scene anchor in {path}: {old[:90]}')
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')


def include(path):
    text=path.read_text(encoding='utf-8')
    directive='#ifdef __EMSCRIPTEN__\n#include "PvzWideScene.h"\n#endif\n'
    if directive not in text:path.write_text(directive+text,encoding='utf-8',newline='\n')


def main():
    for name in ['PvzWideScene.h','PvzWideScene.cpp']:
        shutil.copyfile(ROOT/'third_party/pvz-portable/mobile'/name,SOURCE/name)
    selector=SOURCE/'Lawn/Widget/GameSelector.cpp'
    title=SOURCE/'Lawn/Widget/TitleScreen.cpp'
    reanim=SOURCE/'PvzpLib/Reanimator.cpp'
    for p in [selector,title,reanim]:include(p)
    patch(selector,'GameSelector::GameSelector(LawnApp* theApp)\n{','GameSelector::GameSelector(LawnApp* theApp)\n{\n#ifdef __EMSCRIPTEN__\n\tmClip = false;\n#endif')
    patch(selector,'\tmOverlayWidget->Resize(0, 0, BOARD_WIDTH, BOARD_HEIGHT);','\tmOverlayWidget->Resize(0, 0, BOARD_WIDTH, BOARD_HEIGHT);\n#ifdef __EMSCRIPTEN__\n\tmOverlayWidget->mClip = false;\n#endif')
    patch(title,'void TitleScreen::Draw(Graphics* g)\n{','void TitleScreen::Draw(Graphics* g)\n{\n#ifdef __EMSCRIPTEN__\n\tg->ClearClipRect();\n#endif')
    patch(title,'\tg->DrawImage(IMAGE_TITLESCREEN, 0, 0);','''#ifdef __EMSCRIPTEN__
    PvzWideDrawCover(g, IMAGE_TITLESCREEN);
#else
    g->DrawImage(IMAGE_TITLESCREEN, 0, 0);
#endif''')
    patch(reanim,'\tGetCurrentTransform(theTrackIndex, &aTransform, theFrameTime);\n\tint aImageFrame', '''\tGetCurrentTransform(theTrackIndex, &aTransform, theFrameTime);
#ifdef __EMSCRIPTEN__
    PvzWideSelectorTrack(this, theTrackIndex, &aTransform);
#endif
    int aImageFrame''')
    patch(selector,'\ttheButton->mX = static_cast<int>(aTransform.mTransX + theOffsetX);','''#ifdef __EMSCRIPTEN__
    aTransform.mTransX += PvzWideSelectorOffset(this, theTrackName);
#endif
    theButton->mX = static_cast<int>(aTransform.mTransX + theOffsetX);''')
    patch(selector,'\t\tfloat aTransAreaX = aTransform.mTransX + aOffsetX;','''#ifdef __EMSCRIPTEN__
        aTransform.mTransX += PvzWideSelectorOffset(this, "SelectorScreen_BG_Right");
#endif
        float aTransAreaX = aTransform.mTransX + aOffsetX;''')
    patch(selector,'\taSelectorReanim->GetCurrentTransform(aLeftIdx, &aTransformLeft);','''\taSelectorReanim->GetCurrentTransform(aLeftIdx, &aTransformLeft);
#ifdef __EMSCRIPTEN__
    aTransformLeft.mTransX += PvzWideSelectorOffset(this, "SelectorScreen_BG_Left");
#endif''')
    patch(selector,'\t\taSelectorReanim->GetAttachmentOverlayMatrix(aSignIdx, aOverlayMatrix);','''\t\taSelectorReanim->GetAttachmentOverlayMatrix(aSignIdx, aOverlayMatrix);
#ifdef __EMSCRIPTEN__
        aOverlayMatrix.Translate(PvzWideSelectorOffset(this, "woodsign1") - PvzWideCameraLeft(), 0);
#endif''')
    patch(selector,'\t\t\taTrophyParticle->Draw(g);','''        {
            Graphics trophyGraphics(*g);
#ifdef __EMSCRIPTEN__
            trophyGraphics.Translate(PvzWideSelectorOffset(this, "SelectorScreen_BG_Left"), 0);
#endif
            aTrophyParticle->Draw(&trophyGraphics);
        }''')
    patch(selector,'\t\tint aMouseX = mApp->mWidgetManager->mLastMouseX;','''\t\tint aMouseX = mApp->mWidgetManager->mLastMouseX;
#ifdef __EMSCRIPTEN__
        aMouseX -= static_cast<int>(PvzWideSelectorOffset(this, "SelectorScreen_BG_Left"));
#endif''')
    for x in [20,32]:
        patch(selector,f'\t\t\t\tmToolTip->mX = {x};',f'''\t\t\t\tmToolTip->mX = {x};
#ifdef __EMSCRIPTEN__
                mToolTip->mX += static_cast<int>(PvzWideSelectorOffset(this, "SelectorScreen_BG_Left"));
#endif''')
    old='''\tmApp->ReanimationGet(mLeafReanimID)->Draw(g);
\tfor (int i = 0; i < 3; i++)
\t\tmApp->ReanimationGet(mFlowerReanimID[i])->Draw(g);'''
    new='''    Graphics scenery(*g);
#ifdef __EMSCRIPTEN__
    scenery.Translate(PvzWideSelectorOffset(this, "SelectorScreen_BG_Right"), 0);
#endif
    mApp->ReanimationGet(mLeafReanimID)->Draw(&scenery);
    for (int i = 0; i < 3; i++)
        mApp->ReanimationGet(mFlowerReanimID[i])->Draw(&scenery);'''
    patch(selector,old,new)
    # Static secondary screens preserve their panel coordinates, with native
    # reflected scenery outside the original frame rather than stretching UI.
    scenes={
        'Lawn/Widget/ChallengeScreen.cpp':['IMAGE_CHALLENGE_BACKGROUND'],
        'Lawn/Widget/StoreScreen.cpp':['IMAGE_STORE_BACKGROUND','IMAGE_STORE_BACKGROUNDNIGHT'],
        'Lawn/Widget/AwardScreen.cpp':['IMAGE_AWARDSCREEN_BACK'],
        'Lawn/Widget/AlmanacDialog.cpp':['IMAGE_ALMANAC_INDEXBACK','IMAGE_ALMANAC_PLANTBACK','IMAGE_ALMANAC_ZOMBIEBACK'],
    }
    for relative,names in scenes.items():
        p=SOURCE/relative
        if not p.exists():continue
        cls=p.stem
        include(p)
        patch(p,f'void {cls}::Draw(Graphics* g)\n{{',f'void {cls}::Draw(Graphics* g)\n{{\n#ifdef __EMSCRIPTEN__\n    g->ClearClipRect();\n#endif')
        text=p.read_text(encoding='utf-8')
        for name in names:
            for prefix in ['', 'Sexy::']:
                old=f'g->DrawImage({prefix}{name}, 0, 0);'
                if old not in text:continue
                include(p)
                patch(p,old,f'''#ifdef __EMSCRIPTEN__
    PvzWideDrawBackdrop(g, {prefix}{name}, 0, 0);
#else
    {old}
#endif''')
                text=p.read_text(encoding='utf-8')
    print('Applied proportional native scene layout.')


if __name__=='__main__':main()
