"""Adapt only the Tree of Wisdom background and ground to the Hor+ camera."""
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'vendor/PvZ-Portable'


def patch(path: Path, old: str, new: str) -> None:
    text=path.read_text(encoding='utf-8')
    if new in text:return
    if text.count(old)!=1:raise RuntimeError(f'Unexpected Tree of Wisdom anchor at {path}')
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')


def main() -> None:
    for name in ('PvzWideTree.cpp','PvzWideTree.h'):
        shutil.copyfile(ROOT/'third_party/pvz-portable/mobile'/name,SOURCE/'src'/name)
    source=SOURCE/'src/Lawn/Challenge.cpp'
    patch(source,'#include "Challenge.h"','#include "Challenge.h"\n#ifdef __EMSCRIPTEN__\n#include "../PvzWideTree.h"\n#endif')
    for group,label in ((0,'background'),(3,'ground')):
        old=f'\taReanimTree->DrawRenderGroup(g, {group});  // draw the {label}'
        patch(source,old,f'''#ifdef __EMSCRIPTEN__
\tPvzWideDrawTreeGroup(g,aReanimTree,{group});
#else
{old}
#endif''')
    patch(source,'\t\tPvzpDrawStringMatrix(g, Sexy::FONT_HOUSEOFTERROR16, aMatrix, aSizeStr, Color(255, 255, 255));','''#ifdef __EMSCRIPTEN__
\t\taMatrix.m02 += g->mTransX;
\t\taMatrix.m12 += g->mTransY;
#endif
\t\tPvzpDrawStringMatrix(g, Sexy::FONT_HOUSEOFTERROR16, aMatrix, aSizeStr, Color(255, 255, 255));''')
    print('Applied proportional Tree of Wisdom scenery.')


if __name__=='__main__':main()
