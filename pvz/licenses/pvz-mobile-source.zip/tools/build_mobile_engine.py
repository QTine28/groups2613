"""Build the native mobile bridge with an isolated Emscripten SDK on Windows."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
from apply_mobile_engine import main as apply_patch

ROOT=Path(__file__).resolve().parents[1]


def locate(name: str, supplied: str | None, candidates: list[Path]) -> Path:
    if supplied:
        result=Path(supplied)
    elif shutil.which(name):
        result=Path(shutil.which(name))
    else:
        result=next((p for p in candidates if p.is_file()), Path(name))
    if not result.is_file():
        raise RuntimeError(f"Supply --{name} with the path to {name}.exe")
    return result.resolve()


def main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--cmake")
    parser.add_argument("--ninja")
    parser.add_argument("--jobs",type=int,default=8)
    parser.add_argument("--diagnostics",action="store_true",help="Keep native symbol names and enable Emscripten runtime/stack checks")
    args=parser.parse_args()
    sdk=ROOT/"local"/"emsdk"
    mpt=ROOT/"local"/"libopenmpt"
    source=ROOT/"vendor"/"PvZ-Portable"
    cmake=locate("cmake",args.cmake,[
        Path("F:/vcpkg/downloads/tools/cmake-4.3.2-windows/cmake-4.3.2-windows-x86_64/bin/cmake.exe"),
        Path("C:/Users/PANTOLON/vcpkg/downloads/tools/cmake-3.31.10-windows/cmake-3.31.10-windows-x86_64/bin/cmake.exe")])
    ninja=locate("ninja",args.ninja,[
        Path("F:/vcpkg/downloads/tools/ninja-1.13.2-windows/ninja.exe"),
        Path("C:/Users/PANTOLON/vcpkg/downloads/tools/ninja/1.13.2-windows/ninja.exe")])
    toolchain=sdk/"upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake"
    if not toolchain.is_file() or not (mpt/"Makefile").is_file():
        raise RuntimeError("Install the pinned local emsdk and libopenmpt checkout first; see mobile/README.md")
    env=os.environ.copy()
    env["EM_CONFIG"]=str(sdk/".emscripten")
    env["EMSDK_PYTHON"]=sys.executable
    env["PATH"]=os.pathsep.join([str(sdk/"upstream/emscripten"),str(cmake.parent),str(ninja.parent),env.get("PATH","")])
    def run(*command: str | Path) -> None:
        subprocess.run([str(c) for c in command],cwd=ROOT,env=env,check=True)
    common=["-G","Ninja",f"-DCMAKE_MAKE_PROGRAM={ninja.as_posix()}",f"-DCMAKE_TOOLCHAIN_FILE={toolchain.as_posix()}","-DCMAKE_BUILD_TYPE=Release"]
    mpt_build=ROOT/"local/build-openmpt"
    run(cmake,"-S",ROOT/"third_party/pvz-portable/mobile/openmpt","-B",mpt_build,*common,f"-DOPENMPT_SOURCE={mpt.as_posix()}")
    run(cmake,"--build",mpt_build,"-j",str(args.jobs))
    apply_patch()
    build=ROOT/"local/build-mobile"
    link_flags="-g2 --emit-symbol-map -sASSERTIONS=2 -sSTACK_OVERFLOW_CHECK=2" if args.diagnostics else ""
    run(cmake,"-S",source,"-B",build,*common,f"-DOPENMPT_LIBRARY={(mpt_build/'libopenmpt.a').as_posix()}",f"-DCMAKE_CXX_FLAGS=-I{mpt.as_posix()}",f"-DCMAKE_EXE_LINKER_FLAGS={link_flags}")
    run(cmake,"--build",build,"-j",str(args.jobs))
    print(f"Built {build/'pvz-portable.wasm'} and pvz-portable.js; deployment files have not been replaced.")


if __name__=="__main__":
    main()
