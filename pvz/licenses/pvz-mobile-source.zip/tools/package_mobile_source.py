"""Package exact modified engine source and the static music library sources."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[1]
GIT=Path("C:/Program Files/Git/cmd/git.exe")
OUTPUT=ROOT/"dist/licenses"


def tracked(source: Path) -> list[Path]:
    raw=subprocess.check_output([str(GIT),"-C",str(source),"ls-files","-z"])
    return [source / entry.decode("utf-8") for entry in raw.split(b"\0") if entry]


def archive(destination: Path, entries: list[tuple[Path,str]]) -> dict:
    OUTPUT.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destination,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for path,name in sorted(entries,key=lambda e:e[1]):
            info=zipfile.ZipInfo(name,(2026,11,2,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            out.writestr(info,path.read_bytes())
    size=destination.stat().st_size
    if size>=25*1024*1024:
        raise RuntimeError(f"Archive exceeds the hosting asset limit: {destination}")
    return {"path":str(destination.relative_to(ROOT)),"bytes":size,
            "sha256":hashlib.sha256(destination.read_bytes()).hexdigest(),"files":len(entries)}


def main() -> None:
    engine=ROOT/"vendor/PvZ-Portable"
    engine_files=tracked(engine)+[engine/('src/'+name) for name in ('PvzWide.cpp','PvzWide.h','PvzWideScene.cpp','PvzWideScene.h','PvzWideTree.cpp','PvzWideTree.h')]
    entries=[(p,"vendor/PvZ-Portable/"+p.relative_to(engine).as_posix()) for p in engine_files]
    custom=ROOT/"third_party/pvz-portable/mobile"
    entries.extend((p,p.relative_to(ROOT).as_posix()) for p in custom.rglob("*") if p.is_file())
    for name in ("apply_mobile_engine.py","apply_wide_scene.py","apply_wide_tree.py","apply_wide_effects.py","build_mobile_engine.py","package_mobile_source.py"):
        entries.append((ROOT/"tools"/name,"tools/"+name))
    results=[archive(OUTPUT/"pvz-mobile-source.zip",entries)]
    music=ROOT/"local/libopenmpt"
    allowed_roots={"common","src","soundlib","sounddsp","libopenmpt","build","include"}
    suffixes={".c",".cpp",".h",".hpp",".inc",".inl",".tcc",".txt",".md",".mk",".am",".in",".lua",".cmake"}
    entries=[]
    for p in tracked(music):
        relative=p.relative_to(music)
        if len(relative.parts)==1 or (relative.parts[0] in allowed_roots and (p.suffix.lower() in suffixes or p.name.lower().startswith(("license","copying","copyright","readme")))):
            entries.append((p,"local/libopenmpt/"+relative.as_posix()))
    results.append(archive(OUTPUT/"libopenmpt-0.8.4-source.zip",entries))
    print(json.dumps(results,indent=2))


if __name__=="__main__":
    main()
